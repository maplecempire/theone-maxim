<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>马胜金融-全球交易方案</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333"><?php include('../master/header.php'); ?> </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/cn_maxim.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10"><span class="title10"><span class="title10"><span class="title10">马胜金融-全球交易方案</span></span></span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top"><p class="text1"><?php include('../master/menu_maxim.php'); ?></p></td>
                <td valign="top"><table width="100%"  border="0" cellpadding="10" class="Title04">
                  <tr>
                    <td valign="top" class="text_12_h1"><p align="left" class="Title04">外汇市场是以彼此议定的汇率交换国家货币的场所。外汇市场于20世纪70年代， 目前由于营业额浩大而被认为是世界上最大的金融市场。 根据国际结算银行（2007年3 年度央行调查）的宣布， 全球外汇市场平均每天的营业额估计超过4.5兆美元。</p>
                      <p align="left" class="Title04">现在由于互联网的力量，更多投资者能够参与外汇市场的交易。在这个过去只是银行和其他主要机构才能参与的行业，由于互联网的存在，而把外汇操盘手的种类扩展至散户操盘手。据估计，散户外汇交易或称为“场外” 部分的每天交投量达500-600亿美元，占总外汇市场的百分之二。</p>
                      <p align="left" class="Title04"><strong>公司简介</strong></p>
                      <p align="left" class="Title04">马胜金融是由马胜资本有限公司管理。马胜资本是美国公共挂牌金融和投资信托公司—皇家控股集团公司（Royale Group Holdings Inc.）的子公司。马胜资本是一家金融贸易促成商兼市场调查机构，业务遍及欧洲，并于最近进军亚洲新兴金融强国如中国、香港、韩国及东南亚地区 。</p>
                      <p align="left" class="Title04">马胜金融有一群经验丰富、热衷的交易商、金融分析员及精算师创立， 目的在于为交易和流动资金市场业提供最好的交易方案。</p>
                      <p align="left" class="Title04">马胜金融经营本身的基金管理和专营权账户，为客户提供交易平台， 让专业交易商获得最有竞争力的利率和顶尖交易技术，从而放心地发展他们的业务。除此以外，交易新手也可以从我们的交易专才和专家的经验及指导中受惠。</p>
                      <p align="left" class="Title04">&nbsp;                      </p></td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
