<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Mission &amp; Vision </title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333"><?php include('../master/header.php'); ?> </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/cn_maxim.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10"><span class="title10"><span class="title10"><span class="title10">Mission &amp; Vision </span></span></span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top"><p class="text1">
                  <?php include('../master/menu_maxim.php'); ?>
                </p></td>
                <td valign="top"><table width="100%"  border="0" cellpadding="10" class="Title04">
                  <tr>
                    <td valign="top" class="text_12_h1"><p align="left" class="Title04"><strong>我们的愿景</strong></p>
                      <p align="left" class="Title04">马胜将为投资者在其最佳的交易条件下，提供世界级投资方案。运用其金融工具为投资者在交易活动中，创立一个最佳的资金交易平台，在网上金融市场领域 中创建 全球 性值得信赖的品牌。</p>
                      <p align="left" class="Title04"><strong>我们的使命</strong></p>
                      <p align="left" class="Title04">马胜金融将把汇集的资源最大化，应用完善的基金管理技巧和经过验证的专门知识为全体客户、合作伙伴、利益相关者共同创造财富和价值。</p>
                      <p align="left" class="Title04"><strong>我们的策略</strong></p>
                      <p align="left" class="Title04">马胜金融在新西兰设立亚太区的首间办事处后，迅速把业务扩展到日本、中国、台湾、香港、韩国等地，并且不久将全力向欧洲及非洲扩展。本公司由伯利兹</p>
                      <p align="left" class="Title04">国际金融管理局监管，坚决反对洗黑钱活动，并且拥有卓越的符合法规记录。</p>
                      <p align="left" class="Title04">马胜金融的成长策略以近年来经济迅速扩张，金融服务需求增加的东南亚新兴市场为重点。 马胜对上世纪90 年代外汇期货交易兴起、使大批国内企业和个人趋之若鹜的中国市场，拥有重大的利益。过去，中国的多数外汇操盘手对外汇市场一知半解，以致蒙受巨大亏损。马胜金融的目的是要罗致拥有丰富交易经验的一流投资专才， 除了马胜金融基金管理计划，以扭转这种趋势。</p>
                      <p align="left" class="Title04">中国目前的外汇储备高达2.13兆美元，居世界之冠。 在2009 年的头6 个月，中国的外汇储备更加1856亿美元。 基于中国外汇市场的巨大潜能，马胜金融将继续优先开展中国市场的业务，进行区域性促销和提供本土化产品及服务，同时适应当地的趋势和作业方式。</p>
                      <p align="left" class="Title04">&nbsp;                      </p></td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
