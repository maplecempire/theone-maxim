<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>保障您的投资</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333"><?php include('../master/header.php'); ?> </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/cn_maxim.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10"><span class="title10"><span class="title10"><span class="title10"><span class="title10">保障您的投资</span></span></span></span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top"><p class="text1">
                  <?php include('../master/menu_maxim.php'); ?>
                </p></td>
                <td valign="top"><table width="100%"  border="0" cellpadding="10" class="Title04">
                  <tr>
                    <td valign="top" class="text_12_h1"><p align="left" class="Title04"><strong>对马胜金融而言，我们最关注的莫过于客户自己的安全。</strong></p>
                      <p align="left" class="Title04">客户的所有资金个别和完全由我们母公司—皇家控股集团公司提供的总担保所保障。简言之，客户所投资每一块钱都以我们母公司的相应股份担保。有了这种独一无二的安排，投资者将感到安心，因为他们知道万一马胜破产，投资者手上还持有一家公共上市的纳斯达克场外交易市场公司的股份可以用来减轻他们的损失。</p>
                      <p align="left" class="Title04">马胜金融受到伯利兹国际金融服务管理局（iFSC）的监管，因此顾客对他们的投资没有后顾之忧，因为他们知道他们的投资安全地由一家声誉良好的公司管理。</p>
                      <p align="left" class="Title04"><strong>创造新的事业辉煌</strong></p>
                      <p align="left" class="Title04">马胜金融预见中国对全方位外汇交易及金融方案具有很大的潜力和日益提高的需求。 我们有信心在中国各地主要城市设立至少12 间分行和逐步扩充后，将在今后3 年内创下每年百分之二百的增率，同时继续在外汇交易及流动资金管理，制定核心主业技巧的新基准。</p>
                      <p align="left" class="Title04">马胜在业务上的不断突破，持续带动公司的成长。 2013年，我们推出了创新的MT4 ECN 交易平台和基金管理计划，提供市场上仅仅1000美元的最低按金要求。 随后我们将把服务范围扩大到外汇交易以外，而研发期货交易及二元期权交易。这些服务将在2014年第一季度底启动。</p>
                      <p align="left" class="Title04">马胜金融的愿景是成为外汇交易的先行者公司，雇佣来自全球的熟练人才和由包含外汇交易行业顶尖人才的管理团队掌舵。为了实践这个愿景，公司不断为客户研发新的增值服务。</p>
                      <p align="left" class="Title04"><strong>投资创业</strong></p>
                      <p align="left" class="Title04">我们的投资时以诚信、专业精神提供卓越的个人化服务的企业理念为导向。 我们不断在一个瞬息万变、市场带动的世界里，无时无刻不在物色新的投资和商机。我们以客户的目标及需要为上，通过信任和交出扎实的成绩，打下了坚实的基础。</p>
                      <p align="left" class="Title04">皇家控股集团提倡的企业文化，主张最高水准的符合法规、企业治理及风险管理。 我们可以为个别客户量身制定我们的服务，而且有经验老到的运作管理团队作为强大的后盾。</p>
                      <p align="left" class="Title04">&nbsp;                      </p></td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
