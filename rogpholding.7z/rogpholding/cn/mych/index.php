<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>农业(沉香木) – MY Cameron Hills</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333"><?php include('../master/header.php'); ?> </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/cn_mych.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10"><span class="title10"><span class="title10"><span class="title10">农业 - 沉香木</span></span></span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top"><p class="text1">
                  <?php include('../master/menu_mych.php'); ?>
                </p></td>
                <td valign="top"><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td valign="top" class="text_12_h1"><p align="left" class="Title04">沉香木有世界最珍贵木材的美誉。这种树心部分分泌浓郁香味树脂的树木主要是沉香属（genus Aquilaria）。沉香有许多别称，如蜜香、栈香、沉水香等。最普遍的外文名称有 agar wood、 aloeswood, eaglewood、 gahara、 agalocha 或 oudh (阿拉伯文)。</p>
                      <p align="left" class="Title04">世纪以来，这种名贵的树心被用来制作上等香料。中国人形容沉香的性味为辛、苦，温。中国人、阿拉伯人、日本人及印度人在宗教和佳节时日使用沉香。 沉香在早至中世纪时代的许多传统药典中，占有重要的地位。中医以沉香治疗伤风和消化疾病。从沉香木提取的油脂在阿拉伯通常用作香精。</p>
                      <p align="left" class="Title04">愿景: 成为沉香木生产的先驱，致力于沉香木业的永续发展和提升，把这种商品变成国家的主要收入来源之一。</p>
                      <p align="left" class="Title04">使命: 与各政府部门、决策者及国际沉香木权威密切合作，以成为亚太区沉香木业的佼佼者。</p>
                      <p align="left" class="Title04"><strong>我们的企业理念</strong></p>
                      <div align="left">
                        <table width="100%"  border="0">
                            <tr>
                              <td width="36%"><img src="../../images/wood.jpg" width="296" height="225"></td>
                              <td width="64%"><p align="left" class="Title04"><strong>“视所有顾客为利益关系者”</strong></p>
                                <p align="left" class="Title04">我们与政府部门、决策者及有关当局密切合作， 为会员或利益关系者提供:</p>
                                <p align="left" class="Title04">* 通过研究和协商的一致商业代表权</p>
                                <p align="left" class="Title04">* 专业及商业发展活动</p>
                                <p align="left" class="Title04">* 以良好企业治理价值观和道德操守为基础的商机。</p>
                                <p align="left"></p></td>
                            </tr>
                        </table>
                      </div>                      <p align="left" class="Title04">&nbsp;</p>
                      </td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
