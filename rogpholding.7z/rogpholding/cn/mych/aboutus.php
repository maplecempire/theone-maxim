<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>公司简介</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333"><?php include('../master/header.php'); ?> </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/cn_mych.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10"><span class="title10">公司简介</span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top"><p class="text1">
                  <?php include('../master/menu_mych.php'); ?>
                </p></td>
                <td valign="top"><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td valign="top" class="Title04"><div align="left">
                      <table width="100%" height="0"  border="0">
                          <tr>
                            <td width="0" height="254"><img src="../../images/wood2.jpg" width="324" height="250"></td>
                            <td><p align="left" class="Title04">MY Cameron Hills (MYCH) 成立于2006年，目的是发掘本地区沉香木业的潜能。 MYCH 是皇家集团的子公司，并为投资者和会员发起沉香木商会，以提高他们在本公司投资的价值。沉香木商会会员所享有的利益包括年度表现奖金、医疗和保险保障、度假旅行及名贵汽车等。</p>
                              <p align="left">在 MYCH 项目下，公司在面积超过300 亩的园地共栽种了300,000颗 沉香树； 另外700-800 亩地正在开发以栽种另外700,000颗沉香树。每颗沉香树在5年内的预计产值估计如下:</p>
                              <p align="left">USD2000 每棵树(树龄6-8 年)</p>
                              <p align="left">1,000,000 棵树X USD2000 = USD 20 亿美元</p>
                              <p align="left">&nbsp;</p></td>
                          </tr>
                      </table>
                    </div>                    <p align="left" class="Title04">MYCH 有皇家控股集团公司独资拥有； 皇家控股集团也拥有《金马崙高原生态园》。后者专门开发可持续的高原农业 ， 也是公司与各战略伙伴如农业部、州级国家策划者密切合作推行的一个示范项目，完全按照规定的环境准则落实。<strong><br>
                        <br>
                        沉香木商会</strong><br>
                        马来西亚沉香木商会(AWCCM) 或 Dewan Perniagaan Gaharu Malaysia根据1996年社团法令第7 条于2013年3 月25 日成立及注册。 商会的主要活动之一是推行由MYCH举办的《沉香木企业家计划》（Program Usahawan Gaharu），让退伍军人有机会参与MYCH 发起的商业计划。参与者也接受教育性的讲解，以了解沉香木业的前景。</p>
                      <p align="left"><strong>AWCCM会员利益</strong></p>
                      <p align="left">凡是在AWCCM名册数据库及会员名单上登记的会员都提交给有关当局和有能力及合格落实项目的当地/国际沉香木企业家。</p>
                      <p align="left">&#8226; 会员将享有优先权以象征性收费参加本商会举办的培训课程、研讨会、交流会及其他活动。</p>
                      <p align="left">&#8226; 本商会鼓励沉香木企业家扩大与外界的人脉和商业网络</p>
                      <p align="left">&#8226; 本商会也提供辅导、援助及其他服务支援。</p>
                      <p align="left">&#8226; 会员将受邀参加经常举办的沉香木会议、讲座或研讨会。</p>
                      <p align="left"><strong>前景</strong></p>
                      <p align="left">截至2012年， 本公司已获取超过2万颗沉香树，并在吉打、霹雳、槟城、彭亨、雪兰莪及马六甲等地开辟沉香树园地。 由于革命性沉香种植技术‘Agar wood ISO asc1000 technology’带来的创新突破，大大加速了沉香木业的成长。 有了这种接木技术，沉香树可以在两个月内生产油脂。</p>
                      <p align="left">中东和东北亚的沉香木消费者市场已经相当成熟，在那里，人们世纪以来都使用沉香。 台湾、新加坡、香港和泰国是主要的沉香贸易区，而泰国、马来西亚、印尼及越南则是主要生产国。马来西亚目前是第三大沉香木生产国。 据预测，在最近将来，沉香木的市场需求每年将超过400亿美元。 由于沉香树林的日益稀少，园地栽种的沉香木成为了满足全球需求的新宠。</p></td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
