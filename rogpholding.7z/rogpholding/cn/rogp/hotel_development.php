<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>“我们创造, 建设, 发展资产”</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333"><?php include('../master/header.php'); ?> </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/en_rogp.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10"><span class="title10"><span class="title10"><span class="title10"><span class="title10"><span class="title10">Hotel &amp; Property Developement </span></span></span></span></span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top"><br>
                  <?php include('../master/menu_rogp.php'); ?></td><td valign="top"><table width="100%"  border="0" cellpadding="10" class="Title04">
                  <tr>
                    <td valign="top" class="text_12_h1"><div align="left">
                      <table width="100%"  border="0">
                          <tr>
                            <td width="40%" height="252"><img src="../../images/hotel1.jpg" width="298" height="224"></td>
                            <td width="60%"><p align="left" class="Title04"><strong>“我们创造, 建设, 发展资产”</strong></p>
                              <p align="left">从上世纪60到80年代后期，酒店业出现了一片景气，酒店发展明显增加。随后，酒店业开始走多样化的路线。 大酒店集团的多样化策略和投资方针包括通过资本运作收购，以及把酒店业现有品牌兼并。随着全球经济的复苏，人们对现代廉价酒店的需求日益增加。2012年，廉价酒店市场的价值预计达到260亿美元。</p>
                              <p align="left">我们相信，时下酒店和房地产蓬勃的发展形势，为我们提供良好的机遇，以继续进行更多的收购和争取这个行业的更多管理合约。我们的成长策略包括收购现有的大型房地产、开发新酒店和豪华公寓及发展资产。与此同时，我们建立了强大的管理和销售及营销团队，以应付酒店和房地产发展目标市场部分的需求。我们的其他发展包括下列:</p>
                              </td>
                          </tr>
                      </table>
                    </div>                    <p align="left"><strong>公寓和商场开发</strong></p>
                      <p align="left">皇家控股集团在马泰边界之间的泰南战略地点拥有上选的地皮，以作发展现代公寓、商场及服务公寓之用。鉴于此发展的战略地点和皇家控股集团的管理专才， 据预测此项目的价值约4500万美元。<br>
                        <br>
                        <strong>超级星酒店连锁</strong></p>                      <p align="left">皇家控股集团目前的业务重点是创建一个强调专属性“皇家俱乐部”策略和“忠诚计划”的新的标准酒店连锁。 这项创新商业模式综合我们专属的《皇家俱乐部》的会员特权，以及提供连锁中所有酒店的特别房费。</p>
                      <p align="left"><strong>皇家俱乐部</strong></p>
                      <p align="left">我们的下一个发展—《皇家俱乐部》预料将成为一个高档的娱乐设施。这间俱乐部将体现时尚的现代化建筑学和创新的设计元素。</p>
                      <p align="left">皇家俱乐部将提供尖端的视听设备，营造一种充满活力的氛围和“欢愉情调”。该俱乐部也将特别按照个人的要求，举办私人和促销活动。俱乐部也特地设有私人入口的贵宾区，供私人活动使用，增加俱乐部的私隐和专属性。皇家俱乐部每周开放7天，让会员有机会放松、休闲、充电。</p>
                      </td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
