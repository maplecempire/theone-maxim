<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>我们最靠近的邻居</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333">
            <?php include('../master/header.php'); ?>
          </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/cn_maricom.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10"><span class="title10"><span class="title10"><span class="title10">我们最靠近的邻居</span></span></span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top"><p class="text1">
                  <?php include('../master/menu_maricom.php'); ?>
                </p></td>
                <td valign="top"><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td valign="top" class="text_12_h1"><p align="left" class="Title04">我们‘最靠近的邻居’是CNMC金矿控股有限公司，距离Maricom的 Sokor 金矿区仅数公里。 CNMC在新加坡交易所证券交易有限公司挂牌。CNMC也在Sokor</p>
                      <p align="left" class="Title04">金矿区一个面积2370 亩的地区持有采矿权。马来西亚至少有5 家金矿是上市公司，包括新加坡的CNMC 金矿控股有限公司。</p>
                      <p align="left" class="Title04">2013年6 月， CNMC 宣布其黄金储量增加百分之二十，达到82,000安士。 在截至2013年6 月的6 个月内，该公司的净利为USD482,646美元(马币146万令吉)， 收入达USD517.8万美元(马币1574万令吉)。</p>
                      <p align="left" class="Title04"><strong>Optiro 对“Sokor 金矿项目”的评估</strong></p>
                      <div align="left">
                        <table width="100%"  border="0">
                            <tr>
                              <td width="40%"><img src="../../images/hand_gold.jpg" width="299" height="217"></td>
                              <td width="60%"><p class="Title04">Optiro 有限公司是一家提供矿业各种相关服务的独立咨询机构。该公司的服务范围包括独立地质服务、资源估值、企业顾问、采矿工程、矿场设计、调度、审计、尽职调查及风险评估援助等。由于上述服务的全面性，该公司能够为矿务和采矿公司及其他顾问和投资者提供战略性的独立技术及商业意见， 帮助客户在投产时或之前，作出重要的投资决策，以及把采矿循环的运作价值最大化。该公司聘有行业中最富经验和抢手的地质学家、采矿工程师及专才。</p>
                                <p class="Title04">Opitro 在2012年完成了Sokor 黄金项目的独立《露天矿石储量估计》，并提出以下的结论:</p>
                                <p class="Title04">“根据Optiro 尽可能知道的程度和专门知识， Sokor 黄金项目目前符合一切法律及管制规定。”</p>
                                <p class="Title04">“所有政府准证和执照及法定批准已发出或在发出的过程中。”</p></td>
                            </tr>
                        </table>
                      </div>                      <p align="left" class="Title04"><strong>前景</strong></p>
                      <p align="left" class="Title04">黄金未来的成长受到看好。虽然世界经济可能继续无法与黄金相比，但黄金的有形价值仍旧是黄金实在价值的基础， 而且不管各国央行是否认同这点， 黄金的实在价值将永远不变。</p>
                      <p align="left" class="Title04">Maricom 了解这个情况，决定采取保守的黄金投资及交易平台。经研究，Maricom 管理层预测，在政府实施的货币政策所带来通膨压力下，金价将会飙升。</p>
                      <p align="left" class="Title04">那些准备面对漫长、深切通膨的投资者已经纷纷转向投资黄金，作为应对通膨及保障投资组合稳定的一种方法。那些预料经济和社会结构会崩溃的投资者通常喜欢购买和储藏实物黄金， 因为万一发生社会和经济崩溃的局面，实物黄金可能成为唯一有价值的货币。</p>
                      <p align="left" class="Title04">由于公司的产能不断增加， Sokor 黄金项目将成为马来西亚最大的金矿之一，潜在的黄金产量超过50 公吨， 价值约20-30 亿美元。</p>
                      <p align="left" class="Title04">公司最终的目标是上市，以增加集资，加强财力和争取所有伙伴的支持。我们深信将能实现这个目标。作为对客户的委托，我们将确保公司的利润将重新投入业务，资助业务的扩充，最终惠及利益关系者，提升他们的投资价值。</p>
                      <p align="left">&nbsp;                      </p></td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
