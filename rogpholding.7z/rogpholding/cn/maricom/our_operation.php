<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>公司业务- Maricom金矿</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333">
            <?php include('../master/header.php'); ?>
          </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/cn_maricom.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10"><span class="title10">公司业务- Maricom金矿</span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top"><p class="text1">
                  <?php include('../master/menu_maricom.php'); ?>
                </p></td>
                <td valign="top"><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td valign="top" class="text_12_h1"><p align="left" class="Title04">我们的旗舰项目是Sokor 金矿。除了沙巴州的Mamut 金矿和彭亨州的Penjom 金矿以外，Sokor 金矿区被视为马来西亚最未开发的金矿区。 Sokor 金矿区位于吉兰丹州Tanah Merah 县， 占地5,000 亩。要进入该区必须从Tanah Merah 镇西南取道前往。</p>
                      <p align="left" class="Title04">Maricom金矿是吉兰丹州政府与Maricom 之间按照80对20股权比例经营的合营项目。Maricom持有合资项目80% 的股份。</p>
                      <p align="left" class="Title04">该区下伏轻微变质的二叠纪和三叠纪（Permain and Triassic ）时代火山。二叠纪岩发现于该区的东边，主要包含千枚岩（phyllite）， 期间夹有石灰岩（limestone）、板岩（ slate）、变质砂岩（ metasandstone）及片岩（schist）。</p>
                      <p align="left" class="Title04">此露天矿场已投产，公司采用矿石运输车和挖泥机进行采矿作业。</p>
                      <p align="left" class="Title04">企业责任: 配合环保和社区发展的准则，Maricom严格遵照有关的法规开发、管理采矿作业，把对环境的破坏减到最低程度，同时保持对当地文化和社区生活的敏感度。</p>
                      <p align="left" class="Title04">环保: 为了符合环保条列， Maricom 制定了全面的环境影响评估报告； 此报告在2009年6 月获得吉兰丹环境局通过。此外， Maricom也已制定了该区的环境管理计划，并获得马来西亚环境局的批准。 公司也承诺定期进行环境监督和审查。</p>
                      <p align="left" class="Title04">健康与安全: 本公司将致力于以保护员工和环境的方式开展业务。为了落实这点， 我们也制定了一些环境、健康及安全方针，同时采取额外的防范措施和安全作业程序。</p>
                      <p align="left" class="Title04">社区关系: 我们致力于和矿区附近当地居民打成一片，协助他们的社会及经济发展， 包括提供新的就业机会，为采矿员工提供培训及技能发展，以及扩大经济和商业基础，帮助当地企业成长。</p></td>
                  </tr>
                  <tr>
                    <td valign="top" class="text_12_h1"><img src="../../images/map.jpg" width="557" height="580"></td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
