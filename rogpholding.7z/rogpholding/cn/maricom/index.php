<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Mining (Gold) &ndash; Maricom</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333">
              <?php include('../master/header.php'); ?>
          </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/cn_maricom.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10"><span class="title10">金矿– Maricom</span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top"><p class="text1">
                  <?php include('../master/menu_maricom.php'); ?>
                </p></td>
                <td valign="top"><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td valign="top" class="text_12_h1"><p align="left" class="Title04"><strong>“人类对黄金的欲望是最普遍和根深蒂固的商业本能。” – Gerald M Loeb</strong></p>
                      <p align="left" class="Title04">黄金是为了应对时下经济不稳定局面而套购的投资工具。黄金往往是终极的美元避险投资。 投资者以拥有黄金、共同基金或金矿证券等方式投资黄金，是直接避免美元贬值的最佳手段。当美元下跌时，黄金必然升值。黄金一般上被视为稳当的长远投资和创富的实在资产。以美元买卖黄金，当美元贬值时，金价必定上扬。</p>
                      <p align="left" class="Title04">美元是世界的储备货币和国际交易的主要媒介；储蓄的主要保值；用来计算商品和产权价值的货币； 以及全球央行作为储备而持有的主要货币。 如果除掉美元的黄金支持，美元充其量只不过是一张 漂亮的纸罢了。</p>
                      <p align="left" class="Title04"><strong>Maricom简介</strong></p>
                      <p align="left" class="Title04">Maricom 于2006年由一批专业工程师和地质学家创立，目的是满足全球对黄金这种贵重金属的需求。 Maricom 也是本地区前景最受看好的金矿经营者。 我们的重要资产和业务遍及马来西亚、泰国、香港、澳洲、印尼及加拿大，而总部则设在马来西亚的吉兰丹州。Maricom 经营马来西亚产量最丰富的金矿地点之一，是国内成长最迅速的矿物公司之一。</p>
                      <p align="left" class="Title04">为了成功茁长和扩展业务, Maricom 制定了经营的以下基本原则:</p>
                      <p align="left" class="Title04">愿景: 发挥领先同业的表现，成为最受器重和尊敬的矿业公司</p>
                      <p align="left" class="Title04">使命: 建立能够为股东带来高回报，同时在安全、环境管理及社会责任方面发挥</p>
                      <p align="left" class="Title04">领先地位的永续采矿业务。</p>
                      <p align="left" class="Title04"><strong>我们的价值观:</strong></p>
                      <p align="left" class="Title04">* 以诚信、信任及尊重行事</p>
                      <p align="left" class="Title04">* 对公司所作一切皆追求卓越的承诺</p>
                      <p align="left" class="Title04">* 在安全标准、环境管理及社会责任方面发挥领导作用</p>
                      <p align="left" class="Title04">* 发展人力资源，精益求精</p>
                      <p align="left" class="Title04">* 忠诚、透明及团队精神</p>
                      <p align="left" class="Title04">* 鼓励创新和新技术</p></td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
