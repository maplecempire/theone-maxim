<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
<table width="220"  border="0" cellpadding="4" cellspacing="4">
  <tr>
    <td width="99%" class="hover04"><div align="left"><a href="../rogp/index.php" class="text15" >&#8226; 全球视野</a></div></td>
  </tr>
  <tr>
    <td class="hover04"><div align="left"><a href="../rogp/investment_ventures.php" class="text15" >&#8226; 投资创业</a></div></td>
  </tr>
  <tr>
    <td class="hover04"><div align="left"><a href="../rogp/hotel_development.php" class="text15" >&#8226; 酒店和房地产发展</a></div></td>
  </tr>
  <tr>
    <td class="hover04"><div align="left"><a href="../rogp/competitive_edge.php" class="text15" >&#8226; 竞争优势 - 研发新技术</a></div></td>
  </tr>
</table>
