<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
<META http-equiv=Content-Type content="text/html; charset=utf-8">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">

<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<title></title>
<link href="../css/menu.css" rel="stylesheet" type="text/css">


  <table width="100%"  border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td height="101" valign="top" background="../../images/header_bg.jpg"><div align="center">
          <table width="100%"  border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="46%" height="101"><div align="center">
                <table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td>&nbsp;</td>
                    <td><div align="center"><img src="../../images/logo2.png" width="520" height="79"></div></td>
                  </tr>
                </table>
              </div></td>
              <td width="54%" colspan="2"><div align="center"></div>                <div align="right">
                <div align="right"> </div>
                </div>                <p align="right" class="text_12_h1"><a href="../../en/home/index.php" class="text15"><br>
              </a></p></td>
            </tr>
          </table>
        </div></td>
      </tr>
  </table>
    <table width="100%" height="0"  border="0" cellpadding="0" cellspacing="0" bgcolor="#BA9654">
      <tr>
        <td height="44"><table width="100%"  border="0" cellpadding="0" cellspacing="0" background="../../images/bar.jpg">
          <tr>
            <td width="4%">&nbsp;</td>
            <td width="53%" height="44"><div align="center">
              <ul id="menu">
                  <li>
                    <a href="../home/index.php" class="text12">主页</a></li>
					<li><a href="../rogp/index.php" class="text12">ROGP</a>
                      <ul>
                        <li><a href="../rogp/index.php">全球视野</a></li>
						<li><a href="../rogp/investment_ventures.php">投资创业</a></li>
                            <li><a href="../rogp/hotel_development.php">酒店和房地产发展</a></li>
                            <li><a href="../rogp/competitive_edge.php">竞争优势 - 研发新技术</a></li>
                    </ul>
<li><a href="../maricom/index.php" class="text12">Maricom</a>
                      <ul>
                        <li><a href="../maricom/index.php">Maricom简介</a></li>
                            <li><a href="../maricom/our_operation.php">公司业务</a></li>
                            <li><a href="../maricom/our_nearest_neighbor.php">我们最靠近的邻居</a></li>
                    </ul>
			    <li><a href="../mych/index.php" class="text12">MYCH</a>
			            <ul>
							   <li><a href="../mych/aboutus.php">公司简介</a></li>
		              </ul>
			    <li><a href="../maxim/index.php" class="text12">马胜金融</a>
			            <ul>
                            <li><a href="../maxim/mission_vision.php">我们的愿景</a></li>
                              <li><a href="../maxim/why_choose_us.php">为何选择马胜金融？</a></li>
							  <li><a href="../maxim/securing_your_investment.php">保障您的投资</a></li>

		              </ul>
               <li><a href="../home/contactus.php" class="text12">联系我们</a>
			
              </ul>

                
              </ul>
            </div></td>
          <td width="43%"><div align="right">
            <div align="right">
              <table width="186"  border="0" align="right" cellpadding="0" cellspacing="0">
                <tr class="text1">
                  <td bgcolor="#574106"><div align="center"><a href="../../eng/home/index.php" class="title11">English </a></div></td>
                  <td bgcolor="#574106" class="title10"><div align="center">| </div></td>
                  <td bgcolor="#574106"><div align="center"><a href="../home/index.php" class="title11">&#20013;&#25991;&#29256;</a></div></td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
              </table>
            </div>
            </div></td>
          </tr>
        </table></td>
      </tr>
    </table>

