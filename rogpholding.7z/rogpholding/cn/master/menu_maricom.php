<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
<table width="220"  border="0" cellpadding="4" cellspacing="4">
  <tr>
    <td width="99%" class="hover04"><div align="left"><a href="../maricom/index.php" class="text15" >&#8226; Maricom简介</a></div></td>
  </tr>
  <tr>
    <td class="hover04"><div align="left"><a href="../maricom/our_operation.php" class="text15" >&#8226; 公司业务</a></div></td>
  </tr>
  <tr>
    <td class="hover04"><div align="left"><a href="../maricom/our_nearest_neighbor.php" class="text15" >&#8226; 我们最靠近的邻居</a></div></td>
  </tr>
</table>

