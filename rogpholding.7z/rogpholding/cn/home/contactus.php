<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>把握灿烂未来– 与我们洽谈.</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333">
              <?php include('../master/header.php'); ?>
          </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><img src="../../images/contact.jpg" width="1004" height="195"></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10">把握灿烂未来– 与我们洽谈.</strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top" bgcolor="#F5F5F5"><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td><div align="left"><span class="Title04"><strong><br>
        皇家控股集团</strong>（总公司）<br>
        68 Soi Suphaphong 3,Yak 8 Sirnakarn 40 Road,<br>
        Nonghob Praver, 10250 Thailand<br>
        电话: + 66 8 3184 9191<br>
        传真: + 66 8 2330 9198 </span>
                        </div>
                      <p align="left"><span class="Title04"><strong>马来西亚办事处</strong><br>
        2nd Floor, Wisma Dani, No 1, Jalan Jejaka 4, Taman Maluri, Cheras 55100 Kuala Lumpur<br>
        电话: + 603-9283 7038<br>
        传真: + 603-9183 7068</span><br>
                      </p></td>
                  </tr>
                </table>
                <p class="text1">&nbsp;</p></td>
                <td><table width="100%"  border="0" cellpadding="10" class="Title04">
                  <tr>
                    <td><p align="left" class="Title04">皇家控股集团具备了人力、技术专才、全球网络及财务技巧的全面条件，以进军利润丰厚的金融市场，建立一席立足之地。</p>
                      <p align="left" class="Title04">由于诸如中国等国家的加入， 亚洲金融市场发生了飞速的成长。 为了应对这种趋势，我们正在推出我们的网址、流动应用、流动交易平台等，方便客户在亚洲各地使用。与此同时，我们也加强我们的支援团队，以当地语言为各国客户服务。</p>
                      <p align="left" class="Title04">马胜金融奠下了稳扎交易平台，提供最有竞争性的收费和尖端技术让专业操盘手放心、充满信心地发展事业。</p>
                      <p align="left" class="Title04"><strong>凭我们在全球建立网络的专门知识， 我们具备了必需的条件，通过收购和设立新的业务领域，<br>
                        争取战略性的成长。 这包括:</strong></p>
                      <p align="left" class="Title04">&#8226;  投资创业(RGF 投资有限公司 &amp; Doventure 投资有限公司)</p>
                      <p align="left" class="Title04">&#8226;  LED 照明系统(www.Edison-Thailand.Com)</p>
                      <p align="left" class="Title04">&#8226;  酒店预订及旅游(www.livesasia.com)</p>
                      <p align="left" class="Title04">&#8226;  博彩</p>
                      <p align="left" class="Title04">&#8226;  电讯服务</p>
                      <p align="left" class="Title04">&#8226;  搜索引擎</p></td>
                  </tr>
                </table>                  <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
