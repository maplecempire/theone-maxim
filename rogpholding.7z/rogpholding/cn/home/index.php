<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>皇家控股集团公司（皇家控股集团）</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0" height="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333">
              <?php include('../master/header.php'); ?>
          </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/cn_home.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><span class="title10"><strong>皇家控股（集团）公司-全球优势</strong></span></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top" bgcolor="#F5F5F5"><table width="100%"  border="0" cellpadding="10">
                    <tr>
                      <td><a href="ceo_message.php"><img src="../../images/cn_ceo.jpg" width="208" height="155" border="0"></a></td>
                    </tr>
                    <tr>
                      <td><div align="left"><span class="Title04"><strong><br>
        皇家控股集团</strong>（总公司）<br>
        68 Soi Suphaphong 3,Yak 8 Sirnakarn 40 Road,<br>
        Nonghob Praver, 10250 Thailand<br>
        电话: + 66 8 3184 9191<br>
        传真: + 66 8 2330 9198 </span>
                          </div>
                        <p align="left"><span class="Title04"><strong>马来西亚办事处</strong><br>
        2nd Floor, Wisma Dani, No 1, Jalan Jejaka 4, Taman Maluri, Cheras 55100 Kuala Lumpur<br>
        电话: + 603-9283 7038<br>
        传真: + 603-9183 7068</span><br>
                        </p></td>
                    </tr>
                  </table>                  <p>&nbsp;</p>
                  </td>
                <td valign="top"><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td class="Title04"><p align="left" class="Title04">皇家控股集团公司（皇家控股集团）前称Rohat Resources Inc.， 是美国一家占有全球竞争优势的公共上市金融及投资信托公司。 皇家控股集团成立于2006年，总部设在泰国曼谷。 公司由一群经验丰富、专业、热衷和具备严谨管理技巧, 以及对全球商界独具慧眼的企业家掌管。</p>
                      <p align="left">近年来，皇家控股集团已进军不同的领域如金融和投资、农业、酒店和度假村、房地产开发等行业。 每一个新的商机都为公司带来以效率和信誉服务顾客和委托人的难得经验。</p>
                      <p align="left">过去几年来, 皇家控股集团与珍贵的投资者及国际合作伙伴同步迈进， 发展成一个主要的企业集团。 公司的计划是在2015 年在美国纳斯达克证券交易所挂牌，让投资者赚取丰厚的利润。 在强劲的世界经济带动下，我们将善用财务和管理资源、技术专门知识和经商才干， 发掘全球商场的广大新商机。</p>
                      <div align="left">
                        <table width="100%"  border="0" cellpadding="0">
                            <tr>
                              <td width="53%" valign="top"><table width="91%"  border="0" cellpadding="10" cellspacing="1" bgcolor="#CCCCCC">
                                  <tr>
                                    <td height="280" valign="top" bgcolor="#FFFFFF"><table width="94%"  border="0">
                                        <tr>
                                          <td><img src="../../images/main4.jpg" width="347" height="117"></td>
                                        </tr>
                                        <tr>
                                          <td height="139" valign="top" class="Title04"><div align="justify">
                                            <p><strong>“诚信、奉献、卓越。” - </strong>我们是一家年轻但茁长中的企业，由有一批有奉献精神和坚定毅力的人才掌舵。这个团队包括经验丰富和曾经管理扎实投资组合和经过验证的卓越记录的投资专家。 令我们感到骄傲的是，我们有追求成功和卓越的热诚，而且决心使公司成为全球商场的领先玩家。</p>
                                            </div></td>
                                        </tr>
                                    </table></td>
                                  </tr>
                              </table></td>
                              <td width="47%"><table width="100%"  border="0" cellpadding="10" cellspacing="1" bgcolor="#CCCCCC">
                                  <tr>
                                    <td height="280" valign="top" bgcolor="#FFFFFF"><table width="98%"  border="0">
                                        <tr>
                                          <td><img src="../../images/main5.jpg" width="347" height="117"></td>
                                        </tr>
                                        <tr>
                                          <td height="134" class="Title04"><div align="justify">
                                            <p><strong>公司使命目标- </strong>皇家控股集团 决心和承诺一切以我们的利益相关者为重， 而无论他们是投资者、顾客或是买家， 因为我们相信人人有创富和享受更优质生活方式的权利。</p>
                                            <p>为了落实我们的企业信念，我们矢志成为亚太区第一把交椅的投资公司。</p>
                                            </div></td>
                                        </tr>
                                    </table></td>
                                  </tr>
                              </table></td>
                            </tr>
                            <tr>
                              <td colspan="2" valign="top"><table width="100%"  border="0" cellpadding="10" cellspacing="1" bgcolor="#CCCCCC">
                                  <tr>
                                    <td height="0" valign="top" bgcolor="#FFFFFF" class="Title04"><table width="100%"  border="0">
                                        <tr valign="top">
                                          <td colspan="2" class="Title04"><p><strong>作为场外交易市场(OTC Markets, Over-The-Counter)公司的好处</strong></p>
                                            <p>过去20年，场外交易市场公司是全球金融的主要玩家。由于这些公司目前不完全符合挂牌的规定，它们享有较低的收费和税金，而且在进行交易时，只有买卖双方，没有规范的权力，因此在谈判和安排制定化的交易上，有更多的自由。</p>
                                            <p>随着时代的进步，现代所有证券交易都是采用先进的电子系统在线进行， 而场外交易市场公司的证券是以直接或买入期权方式交易。这种方式费时而且产生压力。因此皇家控股集团提供专门的直接接入证券交易平台，提供在线 场外交易市场证券交易服务。 我们相信这项专门服务将使我们的利益相关者好像在线证券市场操盘手那样进行买卖。这种交易方式有以下的优点:</p>
                                            </td>
                                        </tr>
                                        <tr>
                                          <td width="34%" height="272" class="Title04"><img src="../../images/main1_1.jpg" width="240" height="270"></td>
                                          <td width="66%" class="Title04"><table width="100%"  border="0">
                                              <tr>
                                                <td valign="top" class="Title04">&#8226;</td>
                                                <td class="Title04"> 简化证券交易– 即使是证券操盘新手也可以不必接受任何培训而能够使用这些系统。</td>
                                              </tr>
                                              <tr>
                                                <td valign="top" class="Title04">&#8226;</td>
                                                <td class="Title04">在市场运作时间内能够从任何地方进行交易</td>
                                              </tr>
                                              <tr>
                                                <td valign="top">&#8226;</td>
                                                <td class="Title04">自动化程序，少用文件</td>
                                              </tr>
                                              <tr>
                                                <td valign="top">&#8226;</td>
                                                <td class="Title04">可选择及定制化软件平台</td>
                                              </tr>
                                              <tr>
                                                <td valign="top">&#8226;</td>
                                                <td class="Title04">可以在不受经纪的干预下进行证券交易</td>
                                              </tr>
                                              <tr>
                                                <td valign="top">&#8226;</td>
                                                <td class="Title04"> 快速执行交易指令</td>
                                              </tr>
                                              <tr>
                                                <td valign="top">&#8226;</td>
                                                <td class="Title04"> 实时消息和销售信息</td>
                                              </tr>
                                              <tr>
                                                <td valign="top">&#8226;</td>
                                                <td class="Title04">历史和日内股票走势图表</td>
                                              </tr>
                                              <tr>
                                                <td height="20" valign="top">&#8226;</td>
                                                <td class="Title04">直接接入重要场外交易市场</td>
                                              </tr>
                                              <tr>
                                                <td height="20" colspan="2" class="Title04">其中一些为利益相关者成功赚取可观收益的场外交易市场公司包括全球著名的品牌如 Axa、 BASF、 Deutsche Telecom、 Roche 及 Adidas。</td>
                                              </tr>
                                          </table></td>
                                        </tr>
                                    </table></td>
                                  </tr>
                              </table></td>
                            </tr>
                        </table>
                      </div></td>
                  </tr>
                </table>                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
</div>
</body>
</html>
