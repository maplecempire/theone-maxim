
<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>皇家控股集团公司执行长献词</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333">

              <?php include('../master/header.php'); ?>
          </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/cn_home.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10">皇家控股集团公司执行长献词</span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top" bgcolor="#F5F5F5"><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td><div align="left"><span class="Title04"><strong><br>
        皇家控股集团</strong> （总公司）<br>
        68 Soi Suphaphong 3,Yak 8 Sirnakarn 40 Road,<br>
        Nonghob Praver, 10250 Thailand<br>
        电话: + 66 8 3184 9191<br>
        传真: + 66 8 2330 9198 </span>
                        </div>
                      <p align="left"><span class="Title04"><strong>马来西亚办事处</strong><br>
        2nd Floor, Wisma Dani, No 1, Jalan Jejaka 4, Taman Maluri, Cheras 55100 Kuala Lumpur<br>
        电话: + 603-9283 7038<br>
        传真: + 603-9183 7068</span><br>
                      </p></td>
                  </tr>
                </table>                <p class="text1">&nbsp;</p></td>
                <td><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td><p align="left" class="Title04">中国哲学家老子说，“千里之行始于足下”。自从我们在</p>
                      <p align="left" class="Title04">2006年踏入商界的第一步后，本公司已经从采矿业务扩展 和多样化到超过六种业务。 我们很荣幸地宣布我们目前已在Tanah Merah开设矿场， 进军金矿业务；并在全马各地从事沉香木和尤加利树种植； 在泰国进行酒店和物业发展； 在亚太从事金融和流动资金管理服务、酒店预订和旅游、LED照明系统以及投资创业等业务。估计我们大部分的项目将在5年内成熟， 到时集团的收入预料将达到大约70亿美元。这些收入的来源包括金矿、沉香木和尤加利种植业、物业和发展、金融服务交易及其他业务领域。现在比起任何时候是深入了解和投资本集团的更佳时候。本集团的企业阵容包括有独到眼光和才干的各行业专才，以推行各项计划， 落实改变和提升集团的项目。</p>
                      <p align="left" class="Title04">虽然目前本公司以每股0.15美元的价格在纳斯达克场外交易市场挂牌(于2013年7月18日)。不过我们的企业伙伴向我们保证， 本集团将在今后两年内在纳斯达克主板挂牌，而且到时的股价将远远超出大家的预期。让我们一起完成这个旅程…欢迎加入我们的行列!</p>
                      <p align="left" class="Title04"><strong>Dr David S.P Tan, MBA, PhD</strong></p>
                      <p align="left" class="Title04"><strong>皇家控股集团公司</strong></p>
                      <p align="left" class="Title04"><strong>执行长</strong></p></td>
                  </tr>
                </table>                  <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
