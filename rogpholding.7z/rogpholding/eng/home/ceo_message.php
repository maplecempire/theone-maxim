<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Message from the Desk</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333"><?php include('../master/header.php'); ?> </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" bgcolor="#000000"><iframe src="../../flashbanner/banner/en_home.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10">Message from the Desk <span class="title10"><strong>of the CEO of ROGP</strong></span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top" bgcolor="#F5F5F5"><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td><div align="left"><span class="Title04"><strong><br>
        Royale Group Holding Inc</strong><br>
        (Head Office)<br>
        68 Soi Suphaphong 3,Yak 8 Sirnakarn 40 Road,<br>
        Nonghob Praver, 10250 Thailand<br>
        Tel: + 66 8 3184 9191<br>
        Fax: + 66 8 2330 9198 </span>
                        </div>
                      <p align="left"><span class="Title04"><strong>Malaysia Office</strong><br>
        2nd Floor, Wisma Dani, No 1, Jalan Jejaka 4, Taman Maluri, Cheras 55100 Kuala Lumpur<br>
        Tel: + 603-9283 7038<br>
        Fax: + 603-9183 7068</span><br>
                      </p></td>
                  </tr>
                </table>
                  <p class="text1">&nbsp;</p>                  
                  <p class="text1">&nbsp;</p></td>
                <td><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td><p align="left" class="Title04">Chinese philosopher Lao Tzu once said : &ldquo;A journey of a</p>
                      <p align="left" class="Title04">thousand miles begins with the first step.&rdquo; Since taking ,our first step into the business world in 2006, ROGP hasdiversified and grown from a minerals mining company to include businesses from more than 6 different industries.We take pride to announce that we are now into gold miningwith our mines in Sokor, Tanah Merah, the Agar wood andEucalyptus industries in various sites throughout Malaysia,Hotel and Property Development in Thailand and Financial and Liquidity Management Services in Asia Pacific, Hotel Booking and Travel, LED Lighting Systems and Investment Ventures.</p>
                      <p align="left" class="Title04">In 5 years, it is estimated that when most of our projects come into maturity, the revenue yield expected will be in the region of about US$7 billion. This will include Gold Mining, Agar wood and Eucalyptus plantations, Property and Development, Financial Services Trading and various other business sectors. There has never been a better time to look closely at and thereafter invest in ROGP whose corporate DNA comprise of industry experts and business leaders blessed with excellent foresight and ability to carry out programs that affect change and improvements.</p>
                      <p align="left" class="Title04">We may be listed as a US$0.15 per share company for now (as dated 18th July 2013) on NASDAQ OTC markets, however, our associates have assured us that main board NASDAQ listing is eminent within the next 2 years and with that a share value far exceeding all expectations.</p>
                      <p align="left" class="Title04">Lets&rsquo; make this journey together&hellip; Welcome aboard!.</p>
                      <p align="left" class="Title04"><strong>Dr David S.P Tan MBA, PhD</strong></p>
                      <p align="left" class="Title04"><strong>CEO</strong></p>
                      <p align="left" class="Title04"><strong>Royale Group Holding Inc.</strong></p></td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
