<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Royale Group Holding Inc</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333">
              <?php include('../master/header.php'); ?>
          </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/en_home.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe>  </td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10">Royale Group Holding Inc. &ndash; The Global Advantage</span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top" bgcolor="#F5F5F5"><table width="100%"  border="0" cellpadding="10">
                    <tr>
                      <td><a href="ceo_message.php"><img src="../../images/eng_ceo.jpg" width="208" height="155" border="0"></a></td>
                    </tr>
                    <tr>
                      <td><div align="left"><span class="Title04"><strong><br>
        Royale Group Holding Inc</strong><br>
        (Head Office)<br>
        68 Soi Suphaphong 3,Yak 8 Sirnakarn 40 Road,<br>
        Nonghob Praver, 10250 Thailand<br>
        Tel: + 66 8 3184 9191<br>
        Fax: + 66 8 2330 9198 </span>
                          </div>
                        <p align="left"><span class="Title04"><strong>Malaysia Office</strong><br>
        2nd Floor, Wisma Dani, No 1, Jalan Jejaka 4, Taman Maluri, Cheras 55100 Kuala Lumpur<br>
        Tel: + 603-9283 7038<br>
        Fax: + 603-9183 7068</span><br>
                        </p></td>
                    </tr>
                  </table></td>
                <td><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td height="1027"><p align="left" class="Title04">Formerly known as Rohat Resources Inc., Royale Group Holdings Inc. (ROGP) is a public-listed financial and investment trust company in the United States with a competitive global advantage. Founded in 2006 and headquartered in Bangkok, Thailand, ROGP is managed by a group of experienced, professional and enthusiastic entrepreneurs with prudent management skills and excellent financial foresight in the global business arena.</p>
                      <p align="left" class="Title04">In recent years, ROGP has ventured into different sectors such as finance and investments, agriculture, hotels &amp; resorts, property development and various other industry types. Each new business opportunity offers aninvaluable experience in servicing customers and principals with efficiency and credibility.</p>
                      <p align="left" class="Title04">Through the years, ROGP has evolved into a major business conglomerate progressing with its valued investors and international associates. Come 2015, the plans are for the company to be listed on NASDAQ to enable its investors to make stellar profits. Buoyed up by a vibrant world economy, we are well-poised with financial and management resources, technological expertise and business acumen to harness the vast potential of new business opportunities in the global business arena.</p>
                      <div align="left">
                        <table width="100%"  border="0" cellpadding="0">
                            <tr>
                              <td width="53%" valign="top"><table width="91%"  border="0" cellpadding="10" cellspacing="1" bgcolor="#CCCCCC">
                                  <tr>
                                    <td height="280" valign="top" bgcolor="#FFFFFF"><table width="94%"  border="0">
                                        <tr>
                                          <td><img src="../../images/main2.jpg" width="347" height="117"></td>
                                        </tr>
                                        <tr>
                                          <td><div align="justify"><span class="Title04"><strong>&ldquo;INTEGRITY. DEDICATION. EXCELLENCE.&rdquo;</strong><br>
                        We are young but we are growing. We have a dedicated group of tenacious individuals at the helm&ndash; who are experienced investment experts with solid investment portfolios and a proven track record. We take pride in having a passion for success and excellence with the desire to make the company a leading player in the global business arena. </span></div></td>
                                        </tr>
                                    </table></td>
                                  </tr>
                              </table></td>
                              <td width="47%"><table width="100%"  border="0" cellpadding="10" cellspacing="1" bgcolor="#CCCCCC">
                                  <tr>
                                    <td height="280" valign="top" bgcolor="#FFFFFF"><table width="98%"  border="0">
                                        <tr>
                                          <td><img src="../../images/main3.jpg" width="347" height="117"></td>
                                        </tr>
                                        <tr>
                                          <td height="133"><div align="justify"><span class="Title04"><strong>Our Mission Objective</strong><br>
                        ROGP is dedicated and committed to our &lsquo;stakeholders&rsquo; irrespective of them being investors, customers or buyers. We believe that everyone has a right to create wealth for a betterquality lifestyle. </span>
                                                <p class="Title04">In line with our business credo, we aspire to be the #1 investment company in the Asia-Pacific region.</p>
                                          </div></td>
                                        </tr>
                                    </table></td>
                                  </tr>
                              </table></td>
                            </tr>
                            <tr>
                              <td colspan="2" valign="top"><table width="100%"  border="0" cellpadding="10" cellspacing="1" bgcolor="#CCCCCC">
                                <tr>
                                  <td height="0" valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0">
                                      <tr valign="top">
                                        <td colspan="2"><p class="Title04"><strong>Advantages of being an OTC Markets (Over-The-Counter) company</strong></p>
                                            <p class="Title04">Over the last two decades, OTC markets companies have been a major player in global finance. Currently not fully satisfying listing requirements, these companies enjoy lower fees and taxes and have greater freedom of negotiation and customization of transaction as it involves only a seller and buyer and no standardization of authority.</p>
                                            <p class="Title04">In the modern era, almost all stock trades are done online with advanced electronic systems; with OTC companies, stocks are being traded either directly or call in. This can be time-consuming and stressful &ndash; at ROGP we offer online OTC stock trading services on a specialized direct access stock trading platform. We believe this specialized service will enable all our stakeholders to buy and sell like an online stock market trader. This has certain advantages:</p></td>
                                      </tr>
                                      <tr>
                                        <td width="34%" height="272"><img src="../../images/main.jpg" width="240" height="270"></td>
                                        <td width="66%"><table width="100%"  border="0">
                                            <tr>
                                              <td valign="top" class="Title04">&#8226;</td>
                                              <td><span class="Title04"> Simplicity in stock trading &ndash; even a beginner stock trader can make use of these systems without any training.</span></td>
                                            </tr>
                                            <tr>
                                              <td valign="top"><span class="Title04">&#8226;</span></td>
                                              <td><span class="Title04">Ability to trade from anywhere at market hours</span></td>
                                            </tr>
                                            <tr>
                                              <td valign="top"><span class="Title04">&#8226;</span></td>
                                              <td><span class="Title04">Automated process and involving less paperwork</span></td>
                                            </tr>
                                            <tr>
                                              <td valign="top"><span class="Title04">&#8226;</span></td>
                                              <td><span class="Title04">Choice of selecting and customizing a software platform</span></td>
                                            </tr>
                                            <tr>
                                              <td valign="top"><span class="Title04">&#8226;</span></td>
                                              <td><span class="Title04">Stock trading can be done without broker intervention</span></td>
                                            </tr>
                                            <tr>
                                              <td valign="top"><span class="Title04">&#8226;</span></td>
                                              <td><span class="Title04">High speed order execution</span></td>
                                            </tr>
                                            <tr>
                                              <td valign="top"><span class="Title04">&#8226;</span></td>
                                              <td><span class="Title04">Real time news and time sales</span></td>
                                            </tr>
                                            <tr>
                                              <td valign="top"><span class="Title04">&#8226;</span></td>
                                              <td><span class="Title04">Historical and intraday stock charting</span></td>
                                            </tr>
                                            <tr>
                                              <td height="20" valign="top"><span class="Title04">&#8226;</span></td>
                                              <td><span class="Title04">Direct access to major OTC markets</span></td>
                                            </tr>
                                            <tr>
                                              <td height="20" colspan="2"><span class="Title04">Some successful OTC market companies that have gone on to reap substantial earnings for their stakeholders include a renowned global brands like Axa, BASF, Deutsche Telecom, Roche and Adidas.</span></td>
                                            </tr>
                                        </table></td>
                                      </tr>
                                  </table></td>
                                </tr>
                              </table></td>
                              </tr>
                        </table>                        
                      </div></td>
                  </tr>
                </table>                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
<!--              <?php include('../master/footer.php'); ?>-->
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
