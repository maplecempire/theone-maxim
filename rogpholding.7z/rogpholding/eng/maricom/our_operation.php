<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Mining (Gold) &ndash; Maricom</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333"><?php include('../master/header.php'); ?> </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/en_maricom.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10"><span class="title10"><strong>Our operations - Maricom&rsquo;s Gold Mine</strong></span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top"><?php include('../master/menu_maricom.php'); ?></td>
                <td valign="top"><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td valign="top" class="text_12_h1"><p align="left" class="Title04">Our flagship project is in the Sokor gold field, regarded as the most undeveloped gold mining area in Malaysia, apart from the Mamut Mine in Sabah and the Penjom Mine in Pahang. The Sokor gold field spans an area of 5,000 acres and is located in the district of Tanah Merah in the state of Kelantan, Malaysia. Access to the area is by travelling south west from the town of Tanah Merah.</p>
                      <p align="left" class="Title04">Maricom&rsquo;s gold mine is a 80/20 joint venture between the Kelantan state government and Maricom. The latter holds an 80% share.</p>
                      <p align="left" class="Title04">The area is underlain by mildly metamorphosed volcanoes of the Permian and Triassic age. The Permian rocks are found in the eastern part of the area and comprise mainly phyllite with intercalated limestone, slate, metasandstone and schist.</p>
                      <p align="left" class="Title04">A combination of haul trucks and excavators are utilized in this open pit mining operation, which has since commenced operation.</p>
                      <p align="left" class="Title04">Corporate Responsibility: In line with the guidelines for environmental protection and community development, Maricom develops and manages its mining operations in full compliance, to minimize any harm to the environment at the same time maintaining sensitivity to local culture and community life.</p>
                      <p align="left" class="Title04">Environmental Protection: In compliance with environmental regulations, acomprehensive environmental impact assessment was prepared by Maricom and approved by the Department of Environment, Kelantan in June 2009. In addition, Maricom has in place an environmental management plan for the area whichhas been approved by the Department of Environment of Malaysia. We are also committed to undertake regular environmental monitoring and audit on a regular basis.</p>
                      <p align="left" class="Title04">Health &amp; Safety: We endeavor to conduct our business in such a manner to protect our workers and the environment. To achieve this, we have established certain environment, health and safety policies besides implementing additional preventive measures and safe work procedures for our operations.</p>
                      <p align="left" class="Title04">Community Relations: We strive to integrate with the local population in the vicinity of our mining operations and assisting them in social and economic development. This includes new employment opportunities, training and skills development for the mining staff and a broadened economic and commercial base for local businesses to grow.</p></td>
                  </tr>
                  <tr>
                    <td valign="top" class="text_12_h1"><img src="../../images/map.jpg" width="557" height="580"></td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
