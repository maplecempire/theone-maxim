<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Our Nearest Neighbor</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333"><?php include('../master/header.php'); ?> </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/en_maricom.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10"><span class="title10"><span class="title10">Our Nearest Neighbor</span></span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top">
                  <?php include('../master/menu_maricom.php'); ?>
                </td>
                <td valign="top"><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td valign="top" class="text_12_h1"><p align="left" class="Title04">Our &lsquo;nearest neighbor&rsquo;, just a few kilometers away from Maricom&rsquo;sSokor gold field is CNMC Goldmine Holdings Ltd which is listed on the Singapore Exchange Securities Trading Limited (SGX-ST). CNMC holds the rights to an area of 2370 acres in the Sokor gold field as well. At least 5 gold mines in Malaysia are listed companies, including Singapore&rsquo;s CNMC Goldmine Holdings Ltd.</p>
                      <p align="left" class="Title04">In June 2013, CNMC announced that its gold reserves rose by 20% to 82,000 ounces. For its six months ending June 2013, the company recorded a net profit of USD482,646(RM1.46 million) on a revenue of USD5.178 million(RM15.74 million).</p>
                      <p align="left" class="Title04"><strong>Optiro Review of &ldquo;Sokor Gold Project&rdquo;</strong></p>
                      <div align="left">
                        <table width="100%"  border="0">
                            <tr>
                              <td width="41%"><img src="../../images/hand_gold.jpg" width="299" height="217"></td>
                              <td width="59%"><p class="Title04">Optiro Pty Ltd is an independent consulting organization which provides a range of services related to the minerals industry including independent geological services, resource evaluation, corporate advisory, mining engineering, mine design, scheduling, audit, due diligence and risk assessment assistance. With these services, they are able to provide strategic, independent advice to mining and exploration companies, their advisors and investors. The technical and commercial advice rendered help their clientele to make important investment decisions at or before commencement of operations and maximizes operational value throughout the mining cycle. The company&rsquo;s team of geologists, mining engineers and professionals are among the most experienced and sought after in the industry.</p>
                                <p class="Title04">&nbsp;</p>
                                </td>
                            </tr>
                            <tr>
                              <td colspan="2"><p class="Title04">In an independent Open Pit Ore Reserve Estimation by Optiro for the &ldquo;Sokor Gold Project&rdquo;, completed in April 2012, it was concluded that:</p>
                                <p class="Title04">&ldquo;To the best of Optiro&rsquo;s knowledge and expertise, the Sokor Gold Project is currently compliant with all legal and regulatory requirements.&rdquo;</p>
                                <p class="Title04">&ldquo;All government permits and licenses and statutory approvals are either granted or in the process of being granted.&rdquo;</p></td>
                              </tr>
                        </table>
                      </div>                      <p align="left" class="Title04"><br>
                          <br>
                          <strong>The Future</strong></p>
                      <p align="left" class="Title04">The future growth is going to be seen in gold. Whilst the world economy may remain off the gold standard, the tangible value of gold will remain as the basis for real value &ndash; whether acknowledged by central banks or not &ndash; and will never change.</p>
                      <p align="left" class="Title04">Realizing this scenario, Maricom have decided to turn to the conservative gold investment and trading platform. Through research, the management of Maricomenvisage that gold prices will soar in response to inflationary pressures brought about by the government&rsquo;s monetary policy.</p>
                      <p align="left" class="Title04">Investors who are preparing for steep and prolonged inflation have been flocking to gold as a hedge and as a way to provide stability on their investment portfolios. Investors who envision the breakdown of economic and social structure, usually prefer to buy and store physical gold, which under the circumstance, may be the only currency of value.</p>
                      <p align="left" class="Title04">As the company continues to increase its production capacity, the Sokor Gold Field Project is poised to become one of the largest gold mines in Malaysia with the potential output of more than 50 metric tons of gold worth approx. USD2-3 billion.</p>
                      <p align="left" class="Title04">Our eventual goal is geared towards listing; with the capital raised, the positive growth on financial statements and the mustered support of all partners, we know that this will become a reality. As a corporate mandate to our clients, we will ensure that profits be ploughed back into the business, allowing for expansion and ultimately for stakeholders to realize even more value in their investment.</p>
                      <p align="left">&nbsp;                      </p></td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
