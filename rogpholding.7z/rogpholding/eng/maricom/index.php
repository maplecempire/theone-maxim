<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Mining (Gold) &ndash; Maricom</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333"><?php include('../master/header.php'); ?> </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/en_maricom.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10">Mining (Gold) &ndash; Maricom</span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top">
                  <br>
                  <?php include('../master/menu_maricom.php'); ?></td>
                <td valign="top"><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td valign="top" class="text_12_h1"><p align="left" class="Title04"><strong>&ldquo;The desire for gold is the most universal and deeply rooted commercial instinct of the human race.&rdquo; &ndash; Gerald M Loeb</strong></p>
                      <p align="left" class="Title04">Gold is an investment tool to hedge against current economic uncertainties. The ultimate dollar hedge investment has always been gold. Investing in gold through ownership of the metal itself, mutual funds or gold mining stocks provides the best direct counter to the dollar. As the dollar falls, gold will inevitably rise. Gold is generally regarded as a solid long term investment and a real asset for creating wealth. Bought and sold in US dollars, any decline in the value of the dollar causes the price of gold to rise.</p>
                      <p align="left" class="Title04">US dollar is the world&rsquo;s reserve currency and the primary medium for international transactions, the principal store of value for savings, the currency in which the worth of commodities and equities are calculated, and the currency primarily held as reserves by the central banksworldwide. Stripped of its gold backing, the dollar is nothing more than a fancy piece of paper.</p>
                      <p align="left" class="Title04"><strong>About Maricom</strong></p>
                      <p align="left" class="Title04">Founded in 2006 by a group of professional engineers and geologists, Maricomre presents one of the most prospective goldmine operators in the region, set up to meet the worldwide demand for this precious metal. We have significant assets and operations in Malaysia, Thailand, Hong Kong, Australia, Indonesia and Canada. Headquartered in Kelantan, Malaysia, Maricom is one of the fastest growing mineral companies in Malaysia, operating in one of the most prolific gold mining locations in the country.</p>
                      <p align="left" class="Title04">To successfully grow and expand its business, Maricom has outlined certain fundamentals for its operations:</p>
                      <p align="left" class="Title04">Vision: To be the most valued and respected mining company through industry leading performance</p>
                      <p align="left" class="Title04">Mission: To build a sustainable mining business that delivers high shareholder returns while leading in safety, environmental stewardship and social responsibility</p></td>
                  </tr>
                  <tr>
                    <td valign="top" class="text_12_h1"><div align="left"><span class="Title04"><strong>Our Values:
                      </strong></span> </div>                      <p align="left" class="Title04">&#8226; Act with integrity, trust and respect</p>
                      <p align="left" class="Title04">&#8226; A commitment to excellence in all that we do</p>
                      <p align="left" class="Title04">&#8226; Demonstrate leadership in safety standards, stewardship of the environment and social responsibility</p>
                      <p align="left" class="Title04">&#8226; Development of human resources in pursuit of excellence</p>
                      <p align="left" class="Title04">&#8226; Honesty, transparency and teamwork</p>
                      <p align="left" class="Title04">&#8226; Encourage innovation and new technologies</p></td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
