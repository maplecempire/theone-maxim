<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Agriculture (Agar wood) &ndash; My Cameron Hills</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333"><?php include('../master/header.php'); ?> </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/en_mych.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10"><span class="title10"><span class="title10">Agriculture - Agar wood</span></span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top"><?php include('../master/menu_mych.php'); ?></td>
                <td valign="top"><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td valign="top" class="text_12_h1"><p align="left" class="Title04">Agar wood is reputed to be the most expensive wood in the world. There are basically many names for the resinous, fragrant heartwood produced primarily by trees in the genus Aquilaria. Most commonly the resin is known as agar wood, aloeswood, eaglewood, gahara, agalocha or oudh(Arabic).</p>
                      <p align="left" class="Title04">For many centuries, this precious heartwood has been used to make high quality incense. The Chinese describes its smell as a &lsquo;sweet, deep but balanced fragrance&rsquo; and use it during religious and festive celebrations and so do Arabians, Japanese and Indian people. Agar wood is also a vital part of many traditional pharmacopoeias, dating back to medieval times; Chinese doctors still prescribe it to relieve colds and digestion problems. Oil, extracted from Agar wood is most commonly used in Arabia as perfumery.</p>
                      <p align="left" class="Title04">Vision: To be the pioneer Agar wood producer dedicated to the sustainable development and enhancement of the Agar wood industry and making this commodity a major national income earner.</p>
                      <p align="left" class="Title04">Mission: To be #1 in the Agar wood industry in the Asia Pacific region, working closely with ministries, policy makers and international influencers on the commodity.</p>
                      <p align="left" class="Title04"><strong>Our Business Philosophy</strong></p>
                      <div align="left">
                        <table width="100%"  border="0">
                            <tr>
                              <td width="41%"><img src="../../images/wood.jpg" width="296" height="225"></td>
                              <td width="59%"><p class="Title04">&ldquo;<strong>Taking all our customers as stakeholders&rdquo;</strong></p>
                                <p class="Title04">We work closely with the government sector, policy makers and relevant authorities to provide our members or stakeholders with :</p>
                                <p class="Title04">&bull; A united voice of business representation through research and consultation</p>
                                <p class="Title04">&bull; Professional and business development activities</p>
                                <p class="Title04">&bull; Business opportunities and member benefitsbased on the core values of good governance and ethical propriety.</p></td>
                            </tr>
                        </table>
                      </div></td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
