<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>About us</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333"><?php include('../master/header.php'); ?> </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/en_mych.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10"><span class="title10"><span class="title10">About us</span></span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top"><?php include('../master/menu_mych.php'); ?></td>
                <td valign="top"><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td valign="top" class="text_12_h1"><div align="left">
                      <table width="100%"  border="0">
                            <tr>
                              <td><span class="Title04"><img src="../../images/wood2.jpg" width="324" height="250"></span></td>
                              <td><p align="left" class="Title04">My Cameron Hills (MYCH) was established in 2006 to tap the potential of the prolific Agar wood industry in the region. A subsidiary of the Royale Group of companies, MYCH has initiated the Agar wood Chamber of Commerce for investors and members to grow their investment with us. Membership privileges include yearly performance bonuses, medical &amp; insurance coverage, holiday trips and luxury cars.</p>
                                <p align="left" class="Title04">Our MYCH project has planted 300,000 agar wood trees in more than 300 acre site while another 700-800 acres is being developed for the planting of 700,000 more trees. The Agar wood production is valued at USD2,000 per tree for tree above 6 years old. In 5 years time, the value is estimated at USD2 billion.</p></td>
                            </tr>
                        </table>
                    </div>                    <p align="left" class="Title04">MYCH is wholly owned by Royale Group Holdings Inc. which also owns Cameron Hills Eco Park. The latter is dedicated to developing sustainable highland agriculture and epitomizes a showcase project implemented in close collaboration with strategic partners like the Ministry of Agriculture, state and national planners, and working in full compliance with stipulated environmental guidelines.</p>
                      <p align="left" class="Title04"><strong>Agar wood Chamber of Commerce</strong></p>
                      <p align="left" class="Title04">The Agar wood Chamber of Commerce (AWCCM) or Dewan Perniagaan Gaharu Malaysia, was founded and registered on 25 March 2013 under Section 7 of the Societies Act 1996. One of the main activities of the business entity was the &lsquo;Program Usahawan Gaharu&rsquo; organized by MYCH to give retiring Armed Forces personnel a chance to participate in the business scheme initiated by MYCH. The participants were also given an educational insight into the prospects of the Agar wood industry.</p>
                      <p align="left" class="Title04"><strong>Membership benefits of AWCCM</strong></p>
                      <p align="left" class="Title04">All members are registered in the AWCCM&rsquo;s directory data bank and the members&rsquo; list are forwarded to the authorities concerned, local/international Agar wood entrepreneurs who are capable and qualified to carry out their projects.</p>
                      <p align="left" class="Title04">&#8226; Members will be given priority to participate in training courses, seminars, dialogues and other activities organized by the AWCCM at a minimal fee.</p>
                      <p align="left" class="Title04">&#8226; Agar wood entrepreneurs are encouraged to extend their business networking among themselves and with outside parties.</p>
                      <p align="left" class="Title04">&#8226; AWCCM also provides counseling, assistance and other service logistics.</p>
                      <p align="left" class="Title04">&#8226; Members are also invited to participate in any Agar wood conference, symposium or seminar from time to time.</p>
                      <p align="left" class="Title04"><strong>The Future</strong></p>
                      <p align="left" class="Title04">As at 2012, more than 20,000 trees have been acquired with plantations in Kedah, Perak, Penang, Pahang, Selangor and Melaka. The revolutionary breakthrough of the &lsquo;Agar wood ISO asc1000 technology&rsquo; innovation has accelerated the growth of the industry significantly. Equipped with this inoculation technology, resin production is now possible within two months.</p>
                      <p align="left" class="Title04">The consumer market for Agar wood is well developed in the Middle East and Northeast Asia where Agar wood has been used for centuries. Taiwan, Singapore, Hong Kong and Thailand are major traders of Agar wood while Thailand, Malaysia, Indonesia and Vietnam are major producers. Malaysia is currently the third largest producer of Agar wood. It is envisaged that total market demand for agar wood will exceed $40 billion a year in the near future. The increasing scarcity of Agar wood forests makes plantation grown Agar wood very much sought after to meet global demand.</p>
                      </td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
