<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Mission &amp; Vision </title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333"><?php include('../master/header.php'); ?> </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/en_maxim.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10"><span class="title10"><span class="title10"><span class="title10">Mission &amp; Vision </span></span></span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top"><br>
                  <?php include('../master/menu_maxim.php'); ?></td><td valign="top"><table width="100%"  border="0" cellpadding="10" class="Title04">
                  <tr>
                    <td valign="top" class="text_12_h1"><p align="left" class="Title04"><strong>OUR VISION</strong></p>
                      <p align="left">Maxim Trader aims to provide world class financial solutions to our customers by providing them access to financial instruments at its best trading condition, a safe environment for their trading activities and to build a globally trusted brand in the online trading industry.</p>
                      <p align="left"><strong>OUR MISSION</strong></p>
                      <p align="left">Maxim Trader willmaximize pooled resources, apply sound fund management techniques and proven expertise to generate wealth and create value for all clients, partners and stakeholders.</p>
                      <p align="left"><strong>OUR STRATEGY</strong></p>
                      <p align="left">Maxim Trader opened its first Asia Pacific office in New Zealand, and quickly expanded to Japan, China, Taiwan, Hong Kong, South Korea and soon will be focusing its efforts towards Europe and the Africas. We are also regulated by IFSC Belize, operate against money laundering and have a solid compliance history.</p>
                      <p align="left">Maxim Trader&rsquo;s strategy for growth focuses on the emerging markets of South East Asia, which has experienced rapid expansion and increased demand for financial services in recent years. Maxim Trader has considerable interest in the market in China, where forex futures trading saw a boom in the late 1990&rsquo;s which attracted a large number of domestic enterprises and individuals. Due to the lack of understanding of the forex market, the majority of traders in China have experienced big losses in the past. Maxim Trader aims to reverse this trend by gathering top investment professionals with vast trading experience to form the Maxim Trader Fund Management program.</p>
                      <p align="left">China&rsquo;s foreign exchange reserves currently reach up to 2.13 trillion dollars. The reserves, already the world's largest, grew by 185.6 billion dollars in the first six months of 2009. In view of its tremendous potential, Maxim Trader will continue to place priority on expansion in the China market by offering regional promotions and localized products and services while adapting to local trends and practices.</p>
                      <p align="left" class="Title04">&nbsp;                      </p></td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
