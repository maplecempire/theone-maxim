<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>SECURING YOUR INVESTMENT</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333"><?php include('../master/header.php'); ?> </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/en_maxim.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10"><span class="title10"><span class="title10"><span class="title10"><span class="title10">SECURING YOUR INVESTMENT</span></span></span></span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top">
                  <br>
                  <?php include('../master/menu_maxim.php'); ?>
                </td>
                <td valign="top"><table width="100%"  border="0" cellpadding="10" class="Title04">
                  <tr>
                    <td valign="top" class="text_12_h1"><p align="left" class="Title04"><strong>At Maxim Trader, no other concern is of higher priority than the safety of our clients&rsquo; funds.</strong></p>
                      <p align="left" class="Title04">All of our clients&rsquo; funds are individually and fullysecured in the form of a parental guarantee provided by our parent company, Royale Group Holding Inc. In simple terms, every dollar invested by you is backed by a corresponding share in our parent company. With this unique arrangement, investors can take comfort in the knowledge that in the unlikely event Maxim Trader becomes insolvent, they have in their hands the shares of a public listed NASDAQ OTC markets company that can be used to mitigate against their loses.</p>
                      <p align="left" class="Title04">Maxim Trader is licensed and authorized by the iFSC of Belize, providing customers with peace of mind knowing that their investment is safe in the hands of a reputable company.</p>
                      <p align="left" class="Title04"><strong>CHARTING NEW HEIGHTS</strong></p>
                      <p align="left" class="Title04">Maxim Trader foresees a great potential and increasing demand in China for total Forex and financial solutions. We are optimistic of achieving 200% growth annually for the next 3 years and a gradual expansion rate thereafter involving the opening of at least 12 branches and academies in major cities across China as we continue to set new benchmarks in establishing core competency professional skills in Forextrading and Liquidity Management services.</p>
                      <p align="left" class="Title04">Consistent breakthroughs continue to spur the growth of the company. In year 2013, we launched the innovative MT4 ECN trading along with our Fund Management program with the lowest deposit requirements in the market at just USD1,000. We will also subsequently expand our range of services beyond forex trading into the development of futures trading &amp; binary options trading which will be operational by the end of the first quarter of 2014.</p>
                      <p align="left" class="Title04">With a vision to be a pioneering company in forex trading that engages skilled individuals from around the world, and helmed by a management team comprising top talents in the industry, Maxim Trader continues to evolve and generate new value-added services for the benefit of its clients.</p>
                      </td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
