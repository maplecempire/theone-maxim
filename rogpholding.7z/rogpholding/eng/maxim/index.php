<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>MAXIM TRADER &ndash; Global Trading Solutions</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333"><?php include('../master/header.php'); ?> </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/en_maxim.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10"><span class="title10"><span class="title10"><span class="title10">MAXIM TRADER &ndash; Global Trading Solutions</span></span></span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top"><br>
                  <?php include('../master/menu_maxim.php'); ?></td><td valign="top"><table width="100%"  border="0" cellpadding="10" class="Title04">
                  <tr>
                    <td valign="top" class="text_12_h1"><p align="left" class="Title04"><strong>Welcome to FX TRADING</strong></p>
                      <p align="left">The Foreign Exchange Market (Forex, FX) is the arena in which a nations&rsquo; currency is exchanged for that of another at a mutually agreed rate. It was created in the 1970&prime;s and is now considered to be one of the largest financial markets in the world because of its huge turnover. Based on the announcement of the Bank of International Settlements (in their Triennial Central Bank Survey of 2007), the average daily turnover in global foreign exchange markets is estimated to be over USD4.5 trillion.</p>
                      <p align="left">Through the power of the Internet, e-trading in the Foreign Exchange Market is now made available to a wider range of investors and traders. In an industry where participation only used to be limited to banks and other major institutions, the Internet has furthered the reach of FX traders all the way to retail investors. Retail Forex, also known as &ldquo;off-exchange market&rdquo; segment, is estimated to be worth 2% of the total FX market with daily trading volumes of USD50-60 billion.<br>
                        <br>
                        <strong>WHO ARE WE</strong></p>
                      <p align="left">Maxim Trader is managed by Maxim Capital Limited, part of Royale Group Holding Inc., a public listed Financial and Investment Trust Company in the United States,is a financial trading facilitator and market research house with operations throughout Europe and more recently in the emerging financial powerhouses of Asia like Japan, China, Taiwan, Hong Kong, South Korea &amp; South East Asia.</p>
                      <p align="left">Founded by a group of experienced and enthusiastic traders, financial analysts and actuaries, Maxim Trader aims to provide the best trading solutions for the trading and liquidity markets industry.</p>
                      <p align="left">Maxim Trader runs its own fund management and proprietary account to provide clients with a trading platform that enables professional traders to grow their business with ease of mind, knowing that they are getting the most competitive rates coupled with state-of-the-art trading technology. Additionally, beginner traders will benefit from the experience of and guidance from our trading specialists and experts.</p>
                      <p align="left">&nbsp;                      </p></td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
