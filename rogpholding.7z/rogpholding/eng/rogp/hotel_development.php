<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Hotel &amp; Property Developement </title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333"><?php include('../master/header.php'); ?> </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><iframe src="../../flashbanner/banner/en_rogp.php" width="1004" height="195" frameborder="0" scrolling="No"></iframe></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10"><span class="title10"><span class="title10"><span class="title10"><span class="title10"><span class="title10"><span class="title10">Hotel &amp; Property Developement </span></span></span></span></span></span></strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top"><br>
                  <?php include('../master/menu_rogp.php'); ?></td><td valign="top"><table width="100%"  border="0" cellpadding="10" class="Title04">
                  <tr>
                    <td valign="top" class="text_12_h1"><div align="left">
                      <table width="100%"  border="0">
                          <tr>
                            <td width="40%" height="227"><img src="../../images/hotel1.jpg" width="298" height="224"></td>
                            <td width="60%"><p align="left" class="Title04"><strong>HOTEL &amp; PROPERTY DEVELOPMENT</strong><br>
                              <br>
                              From the early 60s to the late 80s, the hotel industry enjoyed an economic boom &ndash; with a marked increase in hotel development. From hereon, the industry moved in the direction of diversification development. Diversification strategies and investment policies of large hotel groups involved purchases through capital operation and integration of existing brands in the industry. As the global economy recovered and the travel market matured, there was an increasing demand for modern budget hotels. In 2012 the budget hotel market is expected to reach USD26 billion.</p>
                              <p class="Title04">&nbsp;</p></td>
                          </tr>
                      </table>
                    </div>                    <p align="left" class="Title04">Based on the present flourishing hotel and property environment, we believe that it is an opportune time to actively pursue additional acquisitions and management contracts in this business sector. Our growth strategy includes acquisitions of existing mega properties, development of new hotels and luxury condominiums and developing the assets thereon. We believe we have in place a strong management and sales &amp; marketing team who are well-equipped to meet the needs of targeted market segments in hotel and property development.</p>
                      <p align="left" class="Title04"><strong>Some of our other developments include:</strong></p>
                      <p align="left" class="Title04"><strong>Apartment &amp; Mall Development</strong></p>
                      <p align="left" class="Title04">Royale Harmony Company Limited, part of Royale Group Holdings Inc.(ROGP) owns 100 acres of land in Southern Thailand, strategically between the Malaysia-Thailand border. This prime land has been</p>
                      <p align="left" class="Title04">earmarked for the development of modern apartments and shopping malls with serviced apartments. With this strategic location coupled with ROGP&rsquo;s management expertise, the value of the development is approximately worth USD 45million.</p>
                      <p align="left" class="Title04"><strong>Super Star Hotel Chain</strong></p>
                      <p align="left" class="Title04">ROGP is currently focusing on creating a new standard hotel chain with emphasis on an exclusive &lsquo;Royale Club&rsquo; strategy and &lsquo;Royalty Program&rsquo;. This innovative business module combines membership privileges to our very exclusive Royale Club, with special rates at all hotels in the chain.</p>
                      <p align="left" class="Title04"><strong>The Royale Club</strong></p>
                      <p align="left" class="Title04">Our very next development,the Royale Club, is expected to be a premium entertainment establishment. It will incorporate stylish modern architecture with innovative design elements.The essence of a vibrant atmosphere will be provided by state-of-the-art audio and visual facilities to create the desired &lsquo;party mood&rsquo;. The Royale Club will also host private functions and promotional events specially tailored to suit individual demands. For privacy and exclusivity, a special VIP area with a private entrance is also available for special functions. The Royale Club will be open 7 days a week to give members a chance to relax, unwind and recharge.</p>
                      <p align="left" class="Title04"><strong>The Competitive Edge - Research &amp; Development of New Technologies</strong></p>
                      <p align="left" class="Title04">We believe that innovation is essential for market competitiveness and growth. In all our companies&rsquo; operations, we continually invest in research and development of new technologies, from creation, research and design of operational models and platforms to trading online. This constant commitment in technology investments has led to a significant progress in our trading platform, making it even more user friendly. With the exponential increase in online trading as a more efficient and cheaper trading medium compared to traditional ways, we have incorporated these trading techniques extensively to stand out among the rest.</p>
                      <p align="left" class="Title04">&nbsp;                      </p></td>
                  </tr>
                </table>                  
                <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
