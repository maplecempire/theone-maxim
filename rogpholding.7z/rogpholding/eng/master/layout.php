<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Royale Group Holding Inc</title>
<style type="text/css">
<!--
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-repeat:no-repeat;
	background-position:right top;
	background-color: #e9e9e9;
}
-->
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/menu.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<link href="../../css/menu.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <table width="0"  border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td width="21" valign="bottom" background="../../images/sd_left.png"><img src="../../images/sd_left.png" width="21" height="25"></td>
      <td width="1004"><table width="1000"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td bgcolor="#333333"><?php include('../master/header.php'); ?> </td>
        </tr>
        <tr>
          <td valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" bgcolor="#BA9654"></td>
                <td width="78%" bgcolor="#BA9654"></td>
              </tr>
              <tr>
                <td colspan="2" valign="top" bgcolor="#000000"><img src="../../images/index.jpg" width="1004" height="275"></td>
                </tr>
              <tr>
                <td valign="top" bgcolor="#000000">&nbsp;</td>
                <td bgcolor="#000000"><table width="100%"  border="0" cellpadding="10" cellspacing="0">
                  <tr>
                    <td><div align="left"><strong class="title10">The Future Is Here &ndash; Talk To Us. </strong></div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td valign="top"><p class="text1">&nbsp;</p></td>
                <td><table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td><p align="left" class="Title04">At ROGP, we are well-placed with people resources, technical expertise, global networking and financial skills to capture a slice of the lucrative financial market.</p>
                      <p align="left" class="Title04">The Asian financial market has grown by leaps and bounds with countries like China joining the fray. In this aspect, we are working on our website, mobile apps, mobile trading etc to be widely used throughout Asia at the same time reinforcing our support team to provide our services to all countries in their local language.</p>
                      <p align="left" class="Title04">In Maxim Trader, we have set the foundation for a trading platform that enables professional traders to grow their business with ease of mind, confidence and knowledge that they are getting the most competitive rates coupled with the use of state-of-the-art technologies.</p>
                      <p align="left" class="Title04">With our global networking expertise, we are well-positioned for strategic growth with the acquisition and inception of other business sectors. These include :</p>
                      <p align="left" class="Title04">* Investment Ventures (RGF Investment Ltd &amp; Doventure Investment Ltd)</p>
                      <p align="left" class="Title04">* LED lighting systems (www.Edison-Thailand.Com)</p>
                      <p align="left" class="Title04">* Hotel Booking &amp; Travel (www.livesasia.com)</p>
                      <p align="left" class="Title04">* Gaming</p>
                      <p align="left" class="Title04">* Telco Services</p>
                      <p align="left" class="Title04">* Search Engines</p></td>
                  </tr>
                </table>                  <p>&nbsp;</p>
                  </td>
              </tr>
          </table></td>
        </tr>
        <tr>
          <td height="35" bgcolor="#000000"><div align="center" class="text12">
              <?php include('../master/footer.php'); ?>
    </div></td>
        </tr>
        <tr>
          <td><div align="center"> </div></td>
        </tr>
      </table></td>
      <td width="21" valign="bottom" background="../../images/sd_right.png"><img src="../../images/sd_right.png" width="21" height="25"></td>
    </tr>
  </table>
  </div>
</body>
</html>
