<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
<body class="text12">
<div align="center"><span class="text12">Copyright &copy; 2013 Royale Group Holding Inc</span></div>
