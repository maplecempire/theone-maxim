<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">
<table width="220"  border="0" cellpadding="4" cellspacing="4">
  <tr>
    <td width="99%" class="hover04"><div align="left"><a href="../rogp/index.php" class="text15" >&#8226; A Global Outlook</a></div></td>
  </tr>
  <tr>
    <td class="hover04"><div align="left"><a href="../rogp/investment_ventures.php" class="text15" >&#8226; Investment Ventures</a></div></td>
  </tr>
  <tr>
    <td class="hover04"><div align="left"><a href="../rogp/hotel_development.php" class="text15" >&#8226; Hotel & Development</a></div></td>
  </tr>
  <tr>
    <td class="hover04"><div align="left"><a href="../rogp/competitive_edge.php" class="text15" >&#8226; The Competitive Edge</a></div></td>
  </tr>
</table>
