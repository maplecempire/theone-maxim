<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
<META http-equiv=Content-Type content="text/html; charset=utf-8">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
<link href="../../css/mystyle.css" rel="stylesheet" type="text/css">

<link href="../../css/menu.css" rel="stylesheet" type="text/css">
<title></title>
<link href="../css/menu.css" rel="stylesheet" type="text/css">


  <table width="100%"  border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td height="101" valign="top" background="../../images/header_bg.jpg"><div align="center">
          <table width="100%"  border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="46%" height="101"><div align="center">
                <table width="100%"  border="0" cellpadding="10">
                  <tr>
                    <td>&nbsp;</td>
                    <td><div align="center"><img src="../../images/logo.png" width="520" height="79"></div></td>
                  </tr>
                </table>
              </div></td>
              <td width="54%" colspan="2"><div align="center"></div>                <div align="right">
                </div>                
                <p align="center" class="text_12_h1">&nbsp;</p>                <p align="right" class="text_12_h1"><a href="../../en/home/index.php" class="text15"><br>
              </a></p></td>
            </tr>
          </table>
        </div></td>
      </tr>
  </table>
    <table width="100%" height="0"  border="0" cellpadding="0" cellspacing="0" bgcolor="#BA9654">
      <tr>
        <td height="44"><table width="100%"  border="0" cellpadding="0" cellspacing="0" background="../../images/bar.jpg">
          <tr>
            <td width="4%">&nbsp;</td>
            <td width="58%" height="44"><div align="center">
              <ul id="menu">
                  <li>
                    <a href="../home/index.php" class="text12">Home</a></li>
					<li><a href="../rogp/index.php" class="text12">ROGP</a>
                      <ul>
                        <li><a href="../rogp/index.php">A Global Outlook</a></li>
                            <li><a href="../rogp/investment_ventures.php">Investment Ventures</a></li>
							  <li><a href="../rogp/hotel_development.php">Hotel & Development</a></li>
                            <li><a href="../rogp/competitive_edge.php">The Competitive Edge</a></li>
                    </ul>
<li><a href="../maricom/index.php" class="text12">Maricom</a>
                      <ul>
                        <li><a href="../maricom/index.php">About Us</a></li>
                            <li><a href="../maricom/our_operation.php">Our Operation</a></li>
                            <li><a href="../maricom/our_nearest_neighbor.php">Our Nearest Neighbor</a></li>
                    </ul>
					
			    <li><a href="../mych/index.php" class="text12">MYCH</a>
			            <ul>
							   <li><a href="../mych/aboutus.php">About Us</a></li>
		              </ul>
			    <li><a href="../maxim/index.php" class="text12">Maxim Trader</a>
			            <ul>
                            <li><a href="../maxim/mission_vision.php">Mission  & Vision</a></li>
                              <li><a href="../maxim/why_choose_us.php">Why Choose Us?</a></li>
							  <li><a href="../maxim/securing_your_investment.php">Securing your Investement</a></li>

		              </ul>
               <li><a href="../home/contactus.php" class="text12">Contact Us</a>
			
              </ul>

                
              </ul>
            </div></td>
          <td width="38%"><div align="right">
            <table width="186"  border="0" align="right" cellpadding="0" cellspacing="0">
              <tr class="text1">
                <td bgcolor="#574106"><div align="center"><a href="../home/index.php" class="title11">English </a></div></td>
                <td bgcolor="#574106" class="title10"><div align="center">| </div></td>
                <td bgcolor="#574106"><div align="center"><a href="../../cn/home/index.php" class="title11">&#20013;&#25991;&#29256;</a></div></td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
            </table>
          </div>
            </td>
          </tr>
        </table></td>
      </tr>
    </table>

    