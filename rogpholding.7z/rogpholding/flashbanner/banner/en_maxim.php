<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<html lang="en">
<head>
    <title></title>
    <link rel="stylesheet" href="../nivo-slider.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="style.css" type="text/css" media="screen" />
</head>
<body>
<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr>


              <div id="slider" class="nivoSlider">
					<img src="../../images/maxim1.jpg" />
				  <img src="../../images/maxim2.jpg" />
				 <img src="../../images/maxim3.jpg" />


              </div>

            <div id="htmlcaption" class="nivo-html-caption">
                <div align="left"><strong>This</strong> is an example of a <em>HTML</em> capt</div>
            </div>
        

    </td>
  </tr>
</table>
<script type="text/javascript" src="scripts/jquery-1.4.3.min.js"></script>
    <script type="text/javascript" src="../jquery.nivo.slider.js"></script>
    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();
    });
    </script>
</body>
</html>